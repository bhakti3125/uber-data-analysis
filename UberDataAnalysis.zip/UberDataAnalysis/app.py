import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

st.set_page_config(page_title="Uber NYC Data Analysis", layout="wide")
st.title("📊 Uber NYC Data Analysis")

# -------------------------
# Load Data
# -------------------------
@st.cache_data
def load_data():
    df = pd.read_csv("uber_nyc.csv")
    
    # Convert 'Date' to datetime
    df['Date'] = pd.to_datetime(df['Date'])
    
    # Extract additional columns
    df['Day'] = df['Date'].dt.day
    df['Month'] = df['Date'].dt.month
    df['Weekday'] = df['Date'].dt.day_name()
    
    return df

data = load_data()
st.success("✅ Data Loaded Successfully!")
st.dataframe(data.head())

# -------------------------
# Total Trips per Month
# -------------------------
st.subheader("📅 Total Trips Per Month")
trips_per_month = data.groupby('Month')['trips'].sum().reset_index()

plt.figure(figsize=(10,5))
sns.barplot(x='Month', y='trips', data=trips_per_month, palette="viridis")
plt.title("Total Trips Per Month")
plt.xlabel("Month")
plt.ylabel("Number of Trips")
st.pyplot(plt)

# -------------------------
# Total Trips per Weekday
# -------------------------
st.subheader("🗓 Total Trips Per Weekday")
weekday_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
trips_per_weekday = data.groupby('Weekday')['trips'].sum().reindex(weekday_order).reset_index()

plt.figure(figsize=(10,5))
sns.barplot(x='Weekday', y='trips', data=trips_per_weekday, palette="coolwarm")
plt.title("Total Trips Per Weekday")
plt.xlabel("Weekday")
plt.ylabel("Number of Trips")
st.pyplot(plt)

# -------------------------
# Trips by Dispatch Base
# -------------------------
st.subheader("🏙 Trips by Dispatch Base")
trips_per_base = data.groupby('dispatching_base_number')['trips'].sum().reset_index().sort_values(by='trips', ascending=False)

plt.figure(figsize=(12,6))
sns.barplot(x='dispatching_base_number', y='trips', data=trips_per_base, palette="magma")
plt.title("Total Trips by Dispatch Base")
plt.xlabel("Dispatch Base")
plt.ylabel("Number of Trips")
st.pyplot(plt)

# -------------------------
# Active Vehicles over Time
# -------------------------
st.subheader("🚗 Active Vehicles Over Time")
plt.figure(figsize=(12,6))
sns.lineplot(x='Date', y='active_vehicles', data=data, hue='dispatching_base_number', marker="o")
plt.title("Active Vehicles Over Time by Base")
plt.xlabel("Date")
plt.ylabel("Active Vehicles")
plt.legend(title="Base", bbox_to_anchor=(1.05, 1), loc='upper left')
st.pyplot(plt)

# -------------------------
# Filters
# -------------------------
st.sidebar.header("Filters")
month_filter = st.sidebar.multiselect("Select Month(s)", options=list(range(1,13)), default=list(range(1,13)))
weekday_filter = st.sidebar.multiselect("Select Weekday(s)", options=weekday_order, default=weekday_order)
base_filter = st.sidebar.multiselect("Select Dispatch Base(s)", options=data['dispatching_base_number'].unique(), default=data['dispatching_base_number'].unique())

filtered_data = data[
    (data['Month'].isin(month_filter)) &
    (data['Weekday'].isin(weekday_filter)) &
    (data['dispatching_base_number'].isin(base_filter))
]

st.subheader("📄 Filtered Data Preview")
st.dataframe(filtered_data.head())

st.write(f"Total Trips in Filtered Data: {filtered_data['trips'].sum()}")
st.write(f"Total Active Vehicles in Filtered Data: {filtered_data['active_vehicles'].sum()}")